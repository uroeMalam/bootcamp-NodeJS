import React from 'react'

export default function Talent() {
  return (
    <div>Talent</div>
  )
}
