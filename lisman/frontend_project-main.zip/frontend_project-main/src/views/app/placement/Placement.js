import React from 'react'

export default function Placement() {
  return (
    <div>Placement</div>
  )
}
