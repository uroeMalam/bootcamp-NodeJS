import React from 'react'

export default function Curriculum() {
  return (
    <div>Curriculum</div>
  )
}
