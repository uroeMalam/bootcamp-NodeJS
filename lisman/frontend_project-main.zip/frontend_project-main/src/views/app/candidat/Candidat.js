import React from 'react'

export default function Candidat() {
  return (
    <div>Candidat</div>
  )
}
