import React from 'react'

export default function Hiring() {
  return (
    <div>Hiring</div>
  )
}
