import React from 'react';

export default function bootcamp() {
  return <div>
      <h1>Bootcamp Page</h1>
  </div>;
}
