// Drop
// City
export const GET_CITY_REQUEST = "city/get/request";
export const GET_CITY_SUCCESS = "city/get/success";
export const GET_CITY_FAILED = "city/get/failed";
// addressType
export const GET_ADDRESS_TYPE_REQUEST = "address/type/get/request";
export const GET_ADDRESS_TYPE_SUCCESS = "address/type/get/success";
export const GET_ADDRESS_TYPE_FAILED = "address/type/get/failed";
//phoneType
export const GET_PHONE_TYPE_REQUEST = "phone/type/get/request";
export const GET_PHONE_TYPE_SUCCESS = "phone/type/get/success";
export const GET_PHONE_TYPE_FAILED = "phone/type/get/failed";
// SkillType
export const GET_SKILL_TYPE_REQUEST = "skill/type/get/request";
export const GET_SKILL_TYPE_SUCCESS = "skill/type/get/success";
export const GET_SKILL_TYPE_FAILED = "skill/type/get/failed";
