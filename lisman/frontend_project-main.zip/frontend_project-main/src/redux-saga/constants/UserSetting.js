// Get Super
export const GET_USER_REQUEST = "user/get/request";
export const GET_USER_SUCCESS = "user/get/success";
export const GET_USER_FAILED = "user/get/failed";

// Get One User
export const GET_ONE_USER_REQUEST = "user/get/one/request";
export const GET_ONE_USER_SUCCESS = "user/get/one/success";
export const GET_ONE_USER_FAILED = "user/get/one/failed";
